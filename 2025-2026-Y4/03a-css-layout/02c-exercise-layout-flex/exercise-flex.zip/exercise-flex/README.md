# A boilerplate template without CSS styles

The default styling from the browser.
