# A boilerplate template without CSS styles

Default browser styling html
