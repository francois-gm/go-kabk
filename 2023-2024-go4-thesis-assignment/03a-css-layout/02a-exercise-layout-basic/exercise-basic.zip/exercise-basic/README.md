# A boilerplate template without CSS styles

The true default styling from the browser.
